import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import streamlit as st


@st.cache
def load_data():
    pollution=pd.read_csv(r"E:\Air Quality Monitoring\Air_Quality.csv",parse_dates=['last_update'])
    pollution['pollutant_min'] = pollution['pollutant_min'].fillna(pollution['pollutant_min'].mean())
    return pollution

def plot_city_graph(city):
    fig,ax =plt.subplots(figsize=(15,6))
    city_df =pollution[pollution.city==city].copy()
    city_df = city_df.set_index('pollutant_id')
    city_df = city_df[['pollutant_min','pollutant_max','pollutant_avg']]
    city_df.plot(title=f"{city} pollution distribution",ax=ax)
    return fig



pollution = load_data()

cities = pollution.city.unique().tolist()
cols= pollution.columns.tolist()

st.title(" AIR    QUALITY    ANALYSIS   IN   INDIA ")
st.text("Air is what keeps humans alive. Monitoring it and understanding its quality is of") 
st.text( "immense importance to our well-being. The dataset contains air quality data and") 
st.text("and AQI (Air Quality Index) at hourly and daily level of various stations ")
st.text("across multiple cities in India.")

st.sidebar.header("Project options")


options = st.sidebar.radio("Select any one",["Introduction of Project","View Dataset","Data Visualisation",
                          "Project Conclusion"])

if options=="Introduction of Project":
    st.header("Context")
    st.text("Since industrialization, there has been an increasing concern about ")
    st.text("environmental pollution. As mentioned in the WHO report 7 million") 
    st.text("premature deaths annually linked to air pollution , air pollution is the") 
    st.text("world's largest single environmental risk. Moreover as reported in the NY")
    st.text("Times article, India’s Air Pollution Rivals China’s as World’s Deadliest ")
    st.text("it has been found that India's air pollution is deadlier than even China's.")
    st.header("Content")
    st.text("This data is combined(across the years and states) and largely clean version ")
    st.text("of the Historical Daily Ambient Air Quality Data released by the Ministry of ")
    st.text(" Environment and Forests and Central Pollution Control Board of India under the ")
    st.text("National Data Sharing and Accessibility Policy (NDSAP).")
    st.image("air.jpg")
    st.header("Air QUALITY Index (AQI)")
    st.text("The air quality index (AQI) is an index for reporting air quality on a daily basis. ")
    st.text("It is a measure of how air pollution affects one's health within short time period.")
    st.text("The higher the AQI value, the greater the level of air pollution.")
    st.text("AQI keeps a tab on 8 major air pollutants in the atmosphere namely,  ")
    st.text("Particulate Matter (PM2.5)")
    st.image("img1.png")

elif options == "View Dataset":
    st.header("Objective:")
    st.text("Study the air quality of India by finding relevant informations from dataset")
    st.header("Dataset")
    st.text("Using this dataset, we can explore India's air pollution levels at a granular scale.")
    pollution=pd.read_csv(r"E:\Air Quality Monitoring\Air_Quality.csv",parse_dates=['last_update'])
    st.dataframe(pollution)


elif options == "Data Visualisation":
    st.header("Data Visualisation using different Graphs")
    choice=["Pollution Analysis in every city","Every pollutant analysis in every city","Statewise pollution analysis in Decreasing Order"]
    selection = st.sidebar.radio("Select the Option as your need",choice)

    if selection == choice[0]:
        st.header("i type of Visualisation")
        citylist = st.multiselect("Select city/cities whose pollution analysis you wanna see",cities)
        for city in citylist:
            st.pyplot(plot_city_graph(city))

    if selection == choice[1]:
        st.header("ii type of Visualisation")
        fig,ax =plt.subplots(figsize=(15,6))
        df= pollution.groupby(['pollutant_id','city'])['pollutant_min','pollutant_max','pollutant_avg'].max().reset_index()
        plist = df.pollutant_id.unique().tolist()
        p = st.selectbox('Select a pollutant to see its analysis in different cities as your need ',plist)
        with st.spinner("loading"):
            df[df.pollutant_id==p].plot(kind='scatter',y='city',x='pollutant_avg',s='pollutant_avg',c='pollutant_max',cmap='cool',figsize=(8,40),ax=ax,title=f'{p} pollution in cities')
            plt.xticks(rotation=90)
            st.pyplot(fig)
    
    if selection == choice[2]:
        st.header("iii type of Visualisation")
        st.text("Visualisation of Statewise pollution in Decreasing Order")
        fig,ax =plt.subplots(figsize=(15,6)) 
        df= pollution.groupby(['state'])['pollutant_avg'].sum().reset_index()
        df_sorted= df.sort_values('pollutant_avg',ascending=False)
        
        plt.figure(figsize=(23,15))
        ax.bar('state', 'pollutant_avg',data=df_sorted,color=['red','blue','green','violet','orange','green','cyan','pink'])

        plt.xlabel("States", size=25)
        plt.ylabel("Pollution_rate", size=25)

        fig.autofmt_xdate(rotation=45)
        st.pyplot(fig)

elif options== "Project Conclusion":
    st.header("Final conclusion through Analysis")
    st.text("The Highest polluted city is New DELHI, India’s capital is home to some country’s")
    st.text("best-known landmarks, like the Red Fort, India Gate and the Parliament Building.")
    st.text("PM2.5 levels in Delhi have averaged around 180-300 micrograms per cubic metre in")
    st.text(" recent weeks - 12 times higher than the WHO's safe limits. ")
    st.text(' "Lucknow" is among the most polluted cities in the world in terms of PM 2.5 level.')

    st.text('The Highest Polluted State is "Uttar Pradesh" and  ')
    st.text("has an annual average of particulate pollution at 182.9")
    st.text(" microgram per cubic metre air (μg/m3), the second-highest after Delhi.")
    st.text('The Least Polluted State is "Jharkhand" has 60 micrograms per cubic metre in. ')
    
    
